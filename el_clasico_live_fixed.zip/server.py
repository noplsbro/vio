"""EL CLASICO live-score server for Render or local hosting.

Set APIFOOTBALL_KEY in the hosting provider's environment variables.
Never put the API key in index.html or commit it to GitHub.
"""
import os
from datetime import datetime, timezone
from flask import Flask, jsonify, send_from_directory
import requests

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=BASE_DIR, static_url_path="")
API_BASE = "https://v3.football.api-sports.io"
BARCELONA_ID = 529
REAL_MADRID_ID = 541
REQUEST_TIMEOUT = 12


def api_get(path, params):
    api_key = os.environ.get("APIFOOTBALL_KEY", "").strip()
    if not api_key:
        raise RuntimeError("На сервере не задана переменная APIFOOTBALL_KEY")

    response = requests.get(
        f"{API_BASE}{path}",
        headers={"x-apisports-key": api_key},
        params=params,
        timeout=REQUEST_TIMEOUT,
    )
    response.raise_for_status()
    try:
        payload = response.json()
    except ValueError as exc:
        raise RuntimeError("API-Football вернул ответ не в JSON") from exc

    errors = payload.get("errors")
    if errors:
        # API-Football may return either a dict or a list of errors.
        raise RuntimeError(f"Ошибка API-Football: {errors}")
    rows = payload.get("response", [])
    if not isinstance(rows, list):
        raise RuntimeError("Неожиданный формат ответа API-Football")
    return rows


def is_el_clasico(row):
    teams = row.get("teams") or {}
    home_id = (teams.get("home") or {}).get("id")
    away_id = (teams.get("away") or {}).get("id")
    return {home_id, away_id} == {BARCELONA_ID, REAL_MADRID_ID}


def fixture_datetime(row):
    raw = ((row.get("fixture") or {}).get("date") or "")
    try:
        value = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value
    except (TypeError, ValueError):
        return datetime.max.replace(tzinfo=timezone.utc)


def choose_fixture(rows):
    if not rows:
        return None, False
    live_codes = {"1H", "HT", "2H", "ET", "BT", "P", "LIVE"}
    live = [r for r in rows if ((r.get("fixture") or {}).get("status") or {}).get("short") in live_codes]
    if live:
        return sorted(live, key=fixture_datetime)[0], True

    now = datetime.now(timezone.utc)
    future = [r for r in rows if fixture_datetime(r) >= now]
    if future:
        return min(future, key=fixture_datetime), False
    return max(rows, key=fixture_datetime), False


@app.get("/")
def home():
    return send_from_directory(BASE_DIR, "index.html")


@app.get("/health")
def health():
    return jsonify({"ok": True})


@app.get("/api/match")
def match():
    try:
        # Search all currently live fixtures first, then filter the two clubs.
        live_rows = api_get("/fixtures", {"live": "all"})
        live_candidates = [r for r in live_rows if is_el_clasico(r)]
        fixture, is_live = choose_fixture(live_candidates)

        if fixture is None:
            h2h_rows = api_get(
                "/fixtures/headtohead",
                {
                    "h2h": f"{BARCELONA_ID}-{REAL_MADRID_ID}",
                    "last": 1,
                    "next": 1,
                    "timezone": "Europe/Rome",
                },
            )
            candidates = [r for r in h2h_rows if is_el_clasico(r)]
            fixture, is_live = choose_fixture(candidates)

        if fixture is None:
            return jsonify({"fixture": None, "message": "Матч не найден в ответе API-Football"})

        fx = fixture.get("fixture") or {}
        teams = fixture.get("teams") or {}
        goals = fixture.get("goals") or {}
        status = fx.get("status") or {}
        fixture_id = fx.get("id")

        events = []
        if fixture_id:
            for event in api_get("/fixtures/events", {"fixture": fixture_id}):
                time_data = event.get("time") or {}
                player_data = event.get("player") or {}
                assist_data = event.get("assist") or {}
                team_data = event.get("team") or {}
                events.append({
                    "minute": time_data.get("elapsed"),
                    "extra": time_data.get("extra"),
                    "player": player_data.get("name"),
                    "assist": assist_data.get("name"),
                    "team": team_data.get("name"),
                    "type": event.get("type") or "Event",
                    "detail": event.get("detail"),
                })
        events.sort(key=lambda e: (e["minute"] is None, e["minute"] or 0, e["extra"] or 0))

        home = teams.get("home") or {}
        away = teams.get("away") or {}
        return jsonify({
            "fixture": {
                "id": fixture_id,
                "date": fx.get("date"),
                "home": home.get("name"),
                "away": away.get("name"),
                "homeScore": goals.get("home"),
                "awayScore": goals.get("away"),
                "minute": status.get("elapsed"),
                "status": status.get("short"),
                "statusText": status.get("long"),
                "isLive": is_live,
            },
            "events": events,
        })
    except requests.Timeout:
        return jsonify({"error": "timeout", "message": "API-Football не ответил вовремя. Повтори запрос позже."}), 504
    except requests.HTTPError as exc:
        status_code = exc.response.status_code if exc.response is not None else 502
        return jsonify({"error": "upstream_http_error", "message": f"API-Football вернул HTTP {status_code}. Проверь ключ и лимит API."}), 502
    except requests.RequestException:
        app.logger.exception("Network error while calling API-Football")
        return jsonify({"error": "network_error", "message": "Не удалось подключиться к API-Football."}), 502
    except Exception as exc:
        app.logger.exception("Failed to build match response")
        return jsonify({"error": "server_error", "message": str(exc)}), 503


if __name__ == "__main__":
    # Render supplies PORT; 0.0.0.0 is required for hosted web services.
    port = int(os.environ.get("PORT", "8000"))
    app.run(host="0.0.0.0", port=port, debug=False)
