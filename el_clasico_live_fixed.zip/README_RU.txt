EL CLÁSICO ULTIMATE — пакет для онлайн-размещения

Файлы:
- index.html — интерфейс сайта; получает счёт и события с /api/match.
- server.py — Flask API-прокси к API-Football; секретный ключ хранится только на сервере.
- requirements.txt — зависимости Python и Gunicorn.

РАЗМЕЩЕНИЕ НА RENDER С IPHONE
1. Распакуй ZIP в приложении «Файлы».
2. Загрузи index.html, server.py, requirements.txt в GitHub-репозиторий.
3. На Render создай Web Service и подключи репозиторий.
4. Build Command: pip install -r requirements.txt
5. Start Command: gunicorn server:app
6. В Environment добавь APIFOOTBALL_KEY со значением API-ключа.
7. Сохрани изменения и дождись успешного Deploy.
8. Проверь адрес /health — должен вернуться JSON {"ok":true}; затем открой главную страницу.

ВАЖНО
- Не вставляй API-ключ в index.html, GitHub или сообщения.
- Если ранее отправлял ключ в чат, перевыпусти его в кабинете API-Football, если доступно.
- Доступность live-счёта и событий зависит от тарифа и ограничений API-Football.
- Сервер ищет live-матч Barcelona–Real Madrid; если матча нет, показывает ближайший будущий или последний доступный очный матч.
- Интерфейс обновляет счёт каждые 15 секунд. Другие блоки статистики, составов и heatmap в этом дизайне пока демонстрационные, а не реальные данные API.
